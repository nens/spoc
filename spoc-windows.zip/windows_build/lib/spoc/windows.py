from spoc.settings import *

ENVIRONMENT = 'production'

SECRET_KEY = 'liu%(qb17(uvqc7f44i=_^e0bbv^gq11s0q5agzwrxv=c0ufd6'

DATABASES = {
    'default': {
        'NAME': 'spoc',
        'ENGINE': 'django.db.backends.postgresql_psycopg2',
        'USER': 'buildout',
        'PASSWORD': 'buildout',
        'HOST': 'vmhost',
        'PORT': '5432',
        },
    }

try:
    from spoc.localsettings import *
except ImportError:
    pass
