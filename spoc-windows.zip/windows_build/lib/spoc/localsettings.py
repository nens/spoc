
DATABASES = {
    'default': {
        'NAME': 'spoc',
        'ENGINE': 'django.db.backends.postgresql_psycopg2',
        'USER': 'buildout',
        'PASSWORD': 'buildout',
        'HOST': 'localhost',
        'PORT': '5432',
        },
    'kwk': {
        'NAME': 'oei',
        'ENGINE': 'django.db.backends.postgresql_psycopg2',
        'USER': 'buildout',
        'PASSWORD': 'buildout',
        'HOST': 'localhost',
        'PORT': '5432',
        },
    }
