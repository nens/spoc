# (c) Nelen & Schuurmans.  GPL licensed, see LICENSE.rst.
# -*- coding: utf-8 -*-
from __future__ import unicode_literals
from __future__ import print_function

from django.test import TestCase


class ExampleTest(TestCase):

    def test_something(self):
        self.assertEquals(1, 1)
